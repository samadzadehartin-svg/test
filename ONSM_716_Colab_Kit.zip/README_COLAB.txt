ONSM | 716 source records | 244 unique PMID | live full-text-or-abstract study
Source files: ONSM_PubMed_filtered_186, 198, 88, 244_records (2026-11-05).
Deduplication uses PMID for online requests; all source rows are retained in HTML.
Every PMID has its source abstract and DOI. If a full text is publicly downloadable, the
Python script writes the extracted original prose into Word; otherwise the original abstract.
If access checks fail technically, the output records the error and does NOT equate the
error with a confirmed subscription paywall.

SINGLE GOOGLE COLAB CELL:
!pip -q install requests python-docx lxml beautifulsoup4 pymupdf && wget -q -O ONSM_716_Colab_Kit.zip https://raw.githubusercontent.com/samadzadehartin-svg/test/onsm-716-colab-downloads-20261105/ONSM_716_Colab_Kit.zip && unzip -qo ONSM_716_Colab_Kit.zip && python extract_onsm_244.py --input ONSM_716_Records_244_Unique.html --self-test && python extract_onsm_244.py --input ONSM_716_Records_244_Unique.html --output ONSM_244_FullText_or_Abstract.docx --auto-download

COLAB OUTPUT:
ONSM_244_Colab_Results.zip (download prompted automatically)
  ONSM_244_FullText_or_Abstract.docx (244 unique papers, no missing paper)
  ONSM_244_Live_Status.html (searchable results)
  ONSM_244_Access_Report.csv
  ONSM_244_Access_Report.json
ONSM_244_Raw_FullText_Sources.zip (original XML/PDF/BioC/HTML source stored in Colab)

The script does NOT circumvent any publisher login/subscription. OA and full-text links
can change; the number of full texts retrieved is determined only during live execution.
Source wording is not rewritten, but PDF/XML/HTML conversion to Word can change
layout, graphics, formula fidelity and text reading order. Check original sources before
quoting or republishing. Using publicly accessible copies may have licensing restrictions.
You can re-run the script in the same Colab session; checkpoint files are saved per PMID.
