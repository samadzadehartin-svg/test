ONSM 108 OA/full-text candidates (previous Colab access check)

FILES
- ONSM_Free_108_Articles.html : searchable list of 108 unique papers, bibliographic data and links
- extract_108_fulltexts.py   : LIVE full-text acquisition script (Europe PMC JATS, NCBI BioC OA API, public publisher links)

RUN IN GOOGLE COLAB — ONE LINE
!pip -q install requests python-docx lxml beautifulsoup4 pymupdf && wget -q -O ONSM_Free_108_Package.zip https://raw.githubusercontent.com/samadzadehartin-svg/test/onsm-free-108-downloads-20261105/ONSM_Free_108_Package.zip && unzip -qo ONSM_Free_108_Package.zip && python extract_108_fulltexts.py --self-test && python extract_108_fulltexts.py --input ONSM_Free_108_Articles.html --output ONSM_108_Full_Texts.docx --auto-download

RESULTS (produced on Colab, not pre-generated)
- ONSM_108_Full_Texts.docx
- ONSM_108_Live_Status.html
- ONSM_108_Extraction_Report.csv/.json
- ONSM_108_Unmodified_Originals.zip (raw XML/PDF/DOCX/HTML, for verbatim source checking)

Notes: All 108 were classified FREE by the supplied 2026-11-03 Colab audit. A free-to-read link is not proof that a machine-readable full text is downloadable or redistributable. The Python script retries live, does not bypass access control, and never substitutes an abstract for missing full text. Word conversions preserve source prose without rewriting but may differ in equation, figure or PDF layout. Check provider license terms for use and distribution.
